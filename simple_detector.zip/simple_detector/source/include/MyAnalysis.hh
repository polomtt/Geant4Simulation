#ifndef MyAnalysis_h
#define MyAnalysis_h 1 
// #include "g4root.hh"
#include "G4AnalysisManager.hh"
#endif
